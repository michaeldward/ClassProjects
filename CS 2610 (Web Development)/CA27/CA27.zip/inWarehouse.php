<?php
$result = $connect->query("SELECT id, name FROM warehouse");
                ?>
        <h2>Select The Warehouse From the List Below<br/>And Click the List Parts Button</h2>
        <p><label for="warehouse">Warehouse</label>
            <select id="warehouse" name="warehouse" />
            <?php
            while($row = $result->fetch_assoc()) {
                echo "<option value='$row[id]'>$row[name]</option>";
            }
            ?>
            </select>
        </p>            
        <p><input type="submit" id="list" name="list" value="List Parts" /></p>